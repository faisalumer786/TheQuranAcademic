
<?php $__env->startSection('contant'); ?>
<!-- <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Laravel 9 CRUD Example from scratch - ItSolutionStuff.com</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('academic.create')); ?>"> Create New Product</a>
            </div>
        </div>
    </div> -->
    <a class="btn btn-warning m-5 mb-0"
                       href="<?php echo e(route('export')); ?>">
                              Export All Data
                      </a>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
    <table class="table table-bordered">
        <tr class="success">
            <th>No</th>
            <th>Name</th>
            <th>Email</th>
            <th>Contact</th>
            <th>Course</th>
            <th>DOB</th>
            <th>City</th>
            <th>Country</th>
            <th>Gender</th>
            <th width="580px">Action</th>
        </tr>
        <?php $__currentLoopData = $regular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($reg->name); ?></td>
            <td><?php echo e($reg->email); ?></td>
            <td><?php echo e($reg->contact); ?></td>
            <td><?php echo e($reg->course); ?></td>
            <td><?php echo e($reg->date_of_birth); ?></td>
            <td><?php echo e($reg->city); ?></td>
            <td><?php echo e($reg->country); ?></td>
            <td><?php echo e($reg->gender); ?></td>
            <td>
                <form action="<?php echo e(route('regular.destroy',$reg->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wampp\www\AGaffar\resources\views/admin/contant/courses/regular.blade.php ENDPATH**/ ?>